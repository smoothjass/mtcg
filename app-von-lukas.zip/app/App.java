package app;

import app.controllers.CityController;
import app.controllers.UserController;
import app.daos.CityDao;
import app.daos.UserDao;
import app.repositories.UserProfileRepository;
import app.services.CityService;
import app.services.DatabaseService;
import http.ContentType;
import http.HttpStatus;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import server.Request;
import server.Response;
import server.ServerApp;

import java.sql.Connection;
import java.sql.SQLException;

import static java.lang.Integer.parseInt;

@Setter(AccessLevel.PRIVATE)
@Getter(AccessLevel.PRIVATE)
public class App implements ServerApp {
    private CityController cityController;
    private UserController userController;
    private Connection connection;

    // In our app we instantiate all of our DAOs, repositories, and controllers
    // we inject the DAOs to the repos
    // we inject the repos to the controllers
    public App() {
        try {
            setConnection(new DatabaseService().getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // DAOs
        UserDao userDao = new UserDao(getConnection());
        CityDao cityDao = new CityDao(getConnection());

        // Repos
        UserProfileRepository userProfileRepository = new UserProfileRepository(userDao, cityDao);

        // Controllers
        CityController cityController = new CityController(new CityService());
        UserController userController = new UserController(userProfileRepository);

        setCityController(cityController);
        setUserController(userController);
    }

    // the handleRequest Method is used in the server
    // it returns the response to the client
    public Response handleRequest(Request request) {
        // check method
        switch (request.getMethod()) {
            case GET: {
                // check path
                if (request.getPathname().equals("/cities")) {
                    return getCityController().getCities();
                }
                if (request.getPathname().equals("/user-profiles")) {
                    return getUserController().getUserProfiles();
                }
                // check path and path variables
                if (request.getPathname().matches("/user-profiles/\\d+")) {
                    // extract the path variable from the path
                    // you need to make sure its parseable
                    Integer ID = parseInt(request.getPathname().split("/")[2]);
                    return getUserController().getUserProfile(ID);
                }
            }
            case POST: {
                if (request.getPathname().equals("/cities")) {
                    return getCityController().createCity(request.getBody());
                }
            }
        }

        // default response
        return new Response(HttpStatus.NOT_FOUND, ContentType.JSON, "{ \"data\": null, \"error\": \"Route Not Found\" }");
    }
}
